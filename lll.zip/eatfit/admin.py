from django.contrib import admin
from eatfit.models import BD, Comment, Quizz

# Register your models here.


admin.site.register(BD)
admin.site.register(Comment)
admin.site.register(Quizz)
